const toggle = document.querySelector('#toggle');

toggle.addEventListener('change', () => {
  document.body.classList.toggle('dark');
})
function myFunction() {
  var x = document.getElementById("name").value;
  document.getElementById("user-name").innerHTML = "Name: " + x;
  var y = document.getElementById("email").value;
  document.getElementById("user-mail").innerHTML = "Email: " + y;
  var z = document.getElementById("phone").value;
  document.getElementById("user-phone").innerHTML = "Contact No: " + z;
  var w = document.getElementById("message").value;
  document.getElementById("user-message").innerHTML = "Message: " + w;
}
